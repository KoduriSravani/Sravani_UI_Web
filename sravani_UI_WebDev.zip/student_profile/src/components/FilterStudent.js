import React, { useState } from "react";

const FilterStudent = ({ setFilterInput }) => {
  const [scoreFrom, setScoreFrom] = useState(null);
  const [scoreTo, setScoreTo] = useState(null);
  const [classList, setClassList] = useState({
    A: false,
    B: false,
    C: false,
  });

  const handleCheckbox = (e) => {
    const { name } = e.target;
    setClassList((prevState) => {
      return {
        ...prevState,
        [name]: !prevState[name],
      };
    });
  };
  return (
    <div>
      {/* <label>
        Score
        <label>
          from
          <input
            type="number"
            value={scoreFrom}
            onChange={(e) => setScoreFrom(e.target.value)}
          />
        </label>
        <label>
          to
          <input
            type="number"
            value={scoreTo}
            onChange={(e) => setScoreTo(e.target.value)}
          />
        </label>
      </label>

      <label>
        Class
        <label>
          <input
            type="checkbox"
            name="A"
            value="A"
            checked={classList.A}
            onChange={handleCheckbox}
          />
          A
        </label>
        <label>
          <input
            type="checkbox"
            name="B"
            value="B"
            checked={classList.B}
            onChange={handleCheckbox}
          />
          B
        </label>
        <label>
          <input
            type="checkbox"
            name="C"
            value="C"
            checked={classList.C}
            onChange={handleCheckbox}
          />
          C
        </label>
      </label>
      <button
        onClick={() => {
          setFilterInput({ scoreFrom, scoreTo, classList });
        }}
      >
        Filter
      </button> */}

      <div className="container-fluid ">
        <div className="row d-flex justify-content-center ">
          <div className="card d-flex align-items-center py-2 w-75">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setFilterInput({ scoreFrom, scoreTo, classList });
              }}
            >
              <div className="row align-items-center g-3">
                <div className="col-auto">Score</div>
                <div className="col-auto">
                  <div>
                    <label className="form-control-label px-3">From</label>
                    <input
                      type="number"
                      value={scoreFrom}
                      onChange={(e) => setScoreFrom(e.target.value)}
                    />
                  </div>
                  <div className="mt-3">
                    <label className="form-control-label px-3">to</label>
                    <input
                      type="number"
                      value={scoreTo}
                      onChange={(e) => setScoreTo(e.target.value)}
                    />
                  </div>
                </div>

                <div className="col-auto d-flex align-items-center">
                  <p>Class</p>

                  <div className="form-check">
                    <div>
                      <input
                        type="checkbox"
                        name="A"
                        value="A"
                        checked={classList.A}
                        onChange={handleCheckbox}
                      />
                      <label className="form-control-label px-3">A</label>
                    </div>

                    <div>
                      <input
                        type="checkbox"
                        name="B"
                        value="B"
                        checked={classList.B}
                        onChange={handleCheckbox}
                      />
                      <label className="form-control-label px-3">B</label>
                    </div>

                    <div>
                      <input
                        type="checkbox"
                        name="C"
                        value="C"
                        checked={classList.C}
                        onChange={handleCheckbox}
                      />
                      <label className="form-control-label px-3">C</label>
                    </div>
                  </div>
                </div>
                <div className="col-auto">
                  <button type="submit" className="btn btn-primary">
                    Filter
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FilterStudent;

// if (
//   filterInput.scoreFrom < filterInput.scoreTo &&
//   Object.keys(filterInput.classList).length > 0
// ) {
//   if (
//     checkedClass.includes(student.studentClass) &&
//     student.studentScore >= filterInput.scoreFrom &&
//     student.studentScore < filterInput.scoreTo
//   ) {
//     return student;
//   }
// } else if (
//   filterInput.scoreFrom < filterInput.scoreTo &&
//   Object.keys(filterInput.classList).length == 0
// ) {
//   if (
//     student.studentScore >= filterInput.scoreFrom &&
//     student.studentScore < filterInput.scoreTo
//   ) {
//     return student;
//   }
// } else if(Object.keys(filterInput.classList).length > 0) {
//   if (
//     checkedClass.includes(student.studentClass)
//   ) {
//     return student;
//   }
// }
