import React from "react";

const Results = ({ students, setStudents }) => {
  if (!students.length) {
    return <h2 className="mt-3">No Record Found</h2>;
  }
  return (
    <div className="mt-3">
      <table className="table">
        <thead className="thead-dark">
          <tr>
            <th>Student Name</th>
            <th> Score</th>
            <th>Class</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {students.map((student, index) => (
            <tr key={index}>
              <td>{student.studentName}</td>
              <td>{student.studentScore}</td>
              <td>{student.studentClass}</td>
              <td>
                <button
                className="btn btn-danger"
                  onClick={() =>
                    setStudents(students.filter((obj, i) => i !== index))
                  }
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Results;
