import React, { useState } from "react";

const AddStudent = ({ setStudents }) => {
  const [studentName, setStudentName] = useState("");
  const [studentScore, setStudentScore] = useState(null);
  const [studentClass, setStudentClass] = useState("");

  const addStudent = () => {
    setStudents((initialVal) => [
      ...initialVal,
      { studentName, studentClass, studentScore },
    ]);

    emptyState();
  };

  function emptyState() {
    setStudentName("");
    setStudentScore(null);

    setStudentClass("");
  }

  return (
    <div className="container-fluid px-1 py-5 mx-auto">
      <div className="row d-flex justify-content-center">
        <div className="card d-flex align-items-center w-75">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              addStudent();
            }}
          >
            <div className="row align-items-center g-3">
              <div className="col-auto">
                <label className="form-control-label px-3">Student Name</label>
                <input
                  type="text"
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                />
              </div>
              <div className="col-auto">
                <label className="form-control-label px-3">Score</label>
                <input
                  type="number"
                  value={studentScore}
                  onChange={(e) => setStudentScore(e.target.value)}
                />
              </div>
              <div className="col-auto d-flex align-items-center">
                <p>Class</p>

                <div className="form-check">
                  <div>
                    <input
                      type="radio"
                      name="score"
                      value="A"
                      onChange={(e) => setStudentClass(e.target.value)}
                    />
                    <label className="form-control-label px-3">A</label>
                  </div>

                  <div>
                    <input
                      type="radio"
                      name="score"
                      value="B"
                      onChange={(e) => setStudentClass(e.target.value)}
                    />
                    <label className="form-control-label px-3">B</label>
                  </div>

                  <div>
                    <input
                      type="radio"
                      name="score"
                      value="C"
                      onChange={(e) => setStudentClass(e.target.value)}
                    />
                    <label className="form-control-label px-3">C</label>
                  </div>
                </div>
              </div>
              <div className="col-auto">
                <button type="submit" className="btn btn-primary">
                  Create Record
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddStudent;
