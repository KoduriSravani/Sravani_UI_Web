import "./App.css";
import AddStudent from "./components/AddStudent";
import { useState } from "react";
import Results from "./components/Results";
import FilterStudent from "./components/FilterStudent";

function App() {
  const [students, setStudents] = useState([]);
  const [filterInput, setFilterInput] = useState({
    classList: {
      A: false,
      B: false,
      C: false,
    },
  });

  const checkedClass = Object.entries(filterInput.classList)
    .filter((eachClass) => eachClass[1])
    .map((eachClass) => eachClass[0]);
  console.log(checkedClass);

  const filteredStudents = students.filter((student) => {
    if (
      filterInput.scoreFrom < filterInput.scoreTo &&
      checkedClass.length > 0
    ) {
      if (
        checkedClass.includes(student.studentClass) &&
        student.studentScore >= filterInput.scoreFrom &&
        student.studentScore < filterInput.scoreTo
      ) {
        return student;
      }
    } else if (
      filterInput.scoreFrom < filterInput.scoreTo &&
      checkedClass.length === 0
    ) {
      if (
        student.studentScore >= filterInput.scoreFrom &&
        student.studentScore < filterInput.scoreTo
      ) {
        return student;
      }
    } else if (checkedClass.length > 0) {
      if (checkedClass.includes(student.studentClass)) {
        return student;
      }
    }
  });

  console.log(filteredStudents);

  return (
    <div className="App">
      <AddStudent setStudents={setStudents} />
      <FilterStudent setFilterInput={setFilterInput} />
      <Results
        students={
          filterInput.scoreFrom ||
          filterInput.scoreTo ||
          checkedClass.length > 0
            ? filteredStudents
            : students
        }
        setStudents={setStudents}
      />
    </div>
  );
}

export default App;
